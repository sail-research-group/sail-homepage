# Lab 3: FSM and CPU Control for RISKing Processor

## Objective
In this lab, you will implement the Finite State Machine (FSM) and top-level CPU control logic for the RISKing Processor. The datapath and its submodules (ALU, shifter, muxes, register file) have already been completed in previous labs. Your task is to implement the FSM that generates correct control signals and the CPU module that orchestrates instruction execution.

## CPU Module Interface
Your top-level CPU module **must** have the following exact port declaration for compatibility with the testbench:

```systemverilog
module CPU (
  input logic clk,     
  input logic rst,
  input logic [15:0] switches,
  output logic [15:0] data_bus,
  output logic [3:0] status_out,
  output logic fetch,
  // Debugging signals
  output logic [2:0] state_out,
  output logic err
);
```

### Port Descriptions
| Port | Direction | Width | Description |
|------|-----------|-------|-------------|
| `clk` | input | 1 | System clock |
| `rst` | input | 1 | Active-high synchronous reset |
| `switches` | input | 16 | Instruction input |
| `data_bus` | output | 16 | Tri-stated output bus |
| `status_out` | output | 4 | Status flags {Z, N, V, C} |
| `fetch` | output | 1 | Indicates instruction fetch cycle |
| `state_out` | output | 3 | Current FSM state (for debugging) |
| `err` | output | 1 | Error flag for invalid instructions |

## Datapath Interface
Your completed datapath module must have the following interface:

```systemverilog
module datapath (
  input logic        clk,
  input logic        rst,
  input logic [1:0]  vsel,
  input logic        asel,
  input logic        bsel,
  input logic [2:0]  ALUop,
  input logic [1:0]  shift_op,
  input logic        loady,
  input logic        loads,
  input logic [2:0]  rf_waddr,
  input logic        rf_wen,
  input logic [2:0]  rf_raddra,
  input logic [2:0]  rf_raddrb,
  input logic [15:0] datapath_in,
  input logic [15:0] sximm8,
  input logic [15:0] tximm8,
  input logic [15:0] pc_plus1,
  input logic [15:0] sximm5,
  output logic [3:0] status_out,
  output logic [15:0] datapath_out
);
```

## FSM Interface
Your FSM module must have the following interface:

```systemverilog
module FSM(
  input logic clk,
  input logic rst,
  input logic [4:0] ir_opcode,
  output logic [1:0] vsel,
  output logic asel,
  output logic bsel,
  output logic loady,
  output logic loads,
  output logic rf_wen,
  output logic arith_sel,
  output logic dp_gate,
  output logic load_ir,
  output logic [2:0] state_out,
  output logic err_flag
);
```

## Instruction Set Architecture

### Instruction Format (16-bit)

**R-type Instructions:**
| Bits | 15:11 | 10:8 | 7:5 | 4:3 | 2:0 |
|------|-------|------|-----|-----|-----|
| Field | Opcode | Rd | Ra | Shift | Rb |

**I-type Instructions:**
| Bits | 15:11 | 10:8 | 7:5 | 4:0 |
|------|-------|------|-----|-----|
| Field | Opcode | Rd | Ra | Imm5 |

**Immediate Load Instructions:**
| Bits | 15:11 | 10:8 | 7:0 |
|------|-------|------|-----|
| Field | Opcode | Rd | Imm8 |

### Supported Opcodes

| Opcode (binary) | Mnemonic | Type | Description |
|-----------------|----------|------|-------------|
| 5'b00000 | ADD | R-type | Add |
| 5'b00001 | SUB | R-type | Subtract |
| 5'b00010 | ADDC | R-type | Add with Carry |
| 5'b00011 | SUBC | R-type | Subtract with Carry |
| 5'b00100 | AND | R-type | Bitwise AND |
| 5'b00101 | ANDBB | R-type | Bitwise AND with B complemented |
| 5'b00110 | OR | R-type | Bitwise OR |
| 5'b00111 | ORBB | R-type | Bitwise OR with B complemented |
| 5'b01000 | ADDI | I-type | Add Immediate |
| 5'b01001 | SUBI | I-type | Subtract Immediate |
| 5'b10000 | LDI | Load | Load Lower Immediate (sign-extended) |
| 5'b10001 | LUI | Load | Load Upper Immediate |

### Shift Operations (R-type only)

| Shift (binary) | Mnemonic | Operation |
|----------------|----------|-----------|
| 2'b00 | NOS | No shift |
| 2'b01 | LSL | Logical Shift Left |
| 2'b10 | LSR | Logical Shift Right |
| 2'b11 | ASR | Arithmetic Shift Right |

## Functional Requirements

### 1. Instruction Execution Flow
- Instructions are fetched from the `switches` input
- The CPU must decode and execute instructions based on the opcode
- Results are written back to the register file and output to `data_bus`

### 2. Immediate Extension
- **LDI**: Sign-extend 8-bit immediate to 16 bits
- **LUI**: Place 8-bit immediate in upper byte, zero-fill lower byte
- **I-type (ADDI/SUBI)**: Sign-extend 5-bit immediate to 16 bits

### 3. Shift Operation Behavior
For R-type instructions with shift operations:
- The shift is applied to the Rb operand only
- The shift amount is 1 position
- The ALU then performs its operation using Ra and the shifted Rb

Example: `ADD Rd, Ra, Rb, LSL` performs `Rd = Ra + (Rb << 1)`

### 4. Status Flags
The ALU must update status flags appropriately:
- **Z (Zero)**: Set when result is zero
- **N (Negative)**: Set when result MSB is 1
- **V (Overflow)**: Set on arithmetic overflow
- **C (Carry)**: Set on carry out from addition/subtraction

### 5. Tri-state Output
The `data_bus` output must be high-impedance (Z) except during write-back cycles

## FSM Requirements

### States
Your FSM must implement the following states:
- **INIT**: Initial state after reset
- **FETCH**: Load instruction from switches
- **DECODE**: Decode instruction and prepare operands
- **WB**: Write back

### State Transitions
- After reset, FSM enters INIT state
- From INIT, transition to FETCH
- From FETCH, transition to DECODE
- From DECODE, transition based on instruction type:
  - R-type: go to WB, then back to FETCH
  - I-type: go to WB, then back to FETCH
  - LDI/LUI: write RF in DECODE, then back to FETCH

### Control Signals
Your FSM must generate the following control signals:
- `vsel`: Data input select (2 bits)
- `asel`: A operand select
- `bsel`: B operand select (select immediate for I-type)
- `loady`: Load Y register with ALU result
- `loads`: Load status flags
- `rf_wen`: Register file write enable
- `arith_sel`: Select ALU operation source
- `dp_gate`: Enable tri-state buffer for data_bus
- `load_ir`: Load instruction register

## Deliverables

1. **Complete `src/fsm.sv`**: Implement the FSM module with correct state transitions and control signal generation

2. **Complete `src/cpu.sv`**: Implement the top-level CPU module with:
   - Instruction register
   - Instruction decoder
   - Immediate extension units
   - Datapath instantiation
   - FSM instantiation
   - Arithmetic control unit
   - Tri-state output logic

3. Other source files ending with `.sv` or `.v`, if they are implemented and instantiated in the `fsm` and `cpu`

## Testing

Test your implementation using the online simulator. The testbench verifies:
- LUI and LDI instructions with various immediate values
- R-type arithmetic operations (ADD, SUB)
- R-type arithmetic with carry (ADDC, SUBC)
- R-type logical operations (AND, ANDBB, OR, ORBB)
- I-type instructions (ADDI, SUBI)
- Shift operations (LSL, LSR, ASR)
- Sign extension edge cases
- Zero and boundary value handling

