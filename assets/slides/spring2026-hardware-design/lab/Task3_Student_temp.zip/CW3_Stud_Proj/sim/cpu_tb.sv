// You may use this as a template for your testbench. You can modify it as you like, but make sure to keep the module name as cpu_tb and the timescale directive at the top. You can also add more signals and tasks to help with your testing.


`timescale 1ns/1ps

module cpu_tb;

// Supported Instructions
parameter [4:0] 
  ADD = 5'b00000,
  SUB = 5'b00001,
  ADDC = 5'b00010,
  SUBC = 5'b00011,
  AND = 5'b00100,
  ANDBB = 5'b00101,
  OR = 5'b00110,
  ORBB = 5'b00111,
  ADDI = 5'b01000,
  SUBI = 5'b01001,
  LDI = 5'b10000,// Load Lower Immediate, sign-extended imm8 to register
  LUI = 5'b10001;

parameter [1:0]
  NOS = 2'b00, // No shift
  LSL = 2'b01, // Shift left logical with Rb
  LSR = 2'b10, // Shift right logical with Rb
  ASR = 2'b11; // Arithmetic shift right with Rb

parameter [2:0]
  R0 = 3'b000,
  R1 = 3'b001,
  R2 = 3'b010,
  R3 = 3'b011,
  R4 = 3'b100,
  R5 = 3'b101,
  R6 = 3'b110,
  R7 = 3'b111;


// CPU Signals
logic       clk;
logic       rst;
logic [15:0] switches;
logic [15:0] data_bus;
logic [3:0]  status_out;
logic        fetch;

// Instantiate the CPU
CPU DUT (
  .clk(clk),
  .rst(rst),
  .switches(switches),
  .data_bus(data_bus),
  .status_out(status_out),
  .fetch(fetch)
);

integer i;
integer fd; // File descriptor for logging



// Clock generation
initial begin
  clk = 0;
  forever #5 clk = ~clk; // 100 MHz clock
end

// Test sequence
initial begin
 
/*********** Fill your code below *****************/




/*********** End of your code *******************/

  $finish;
end


// Force finish after some time to prevent infinite simulation
initial begin
  #10000;
  print("Test timed out!");
  $finish;
end



endmodule