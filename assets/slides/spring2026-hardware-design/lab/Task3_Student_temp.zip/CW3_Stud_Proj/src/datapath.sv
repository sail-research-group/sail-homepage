// Module: datapath
// Description: Datapath for RISKing Processor
// Datapath need update:
// 1. Add two more input source. In total:
//                      |\
//   tail extended imm8 |3|
//   sign extended imm8 |2|
//   pc_plus1           |1|
//   data from data bus |0|
//                      |/
//   pc_plus1 is not used in Lab 3, but you need to implement the mux for it. 
//   You will use it in Lab 5 when implementing the jump and branch instructions.
//
// 2. vsel control signal is two bits now



module datapath (
  input logic        clk,         // Clock input
  input logic        rst,         // Reset signal

  //datapath control signals
  input logic [1:0]  vsel,        // Data input select
  input logic        asel,        // A operand select
  input logic        bsel,        // B operand select
  input logic [2:0]  ALUop,       // ALU operation code
  input logic [1:0]  shift_op,    // Shift operation code
  input logic        loady,       // Load Y register: Results from ALU
  input logic        loads,       // Load S register: Status flags from ALU
  // Register file control signals
  input logic [2:0]  rf_waddr,    // Write register number
  input logic        rf_wen,      // Write enable signal
  input logic [2:0]  rf_raddra,   // Read register a number
  input logic [2:0]  rf_raddrb,   // Read register b number
  // Data input
  input logic [15:0] datapath_in, // 16-bit data input
  input logic [15:0] sximm8,      // Sign-extended immediate value (from instruction)
  input logic [15:0] tximm8,      // Tail-extended immediate value (from instruction)
  input logic [15:0] pc_plus1,    // PC + 1 value                  (from PC module  }
  input logic [15:0] sximm5,      // Sign-extended immediate value (from instruction)

  // Data output
  output logic [3:0]  status_out,    // Status flags output
  output logic [15:0] datapath_out      // 16-bit data output
);



/*********** Fill your code below *****************/

regfile_2p RF_inst (
  .clk(),
  .rst(),
  .wen(),
  .waddr(),
  .wdata(),
  .raddr1(),
  .rdata1(),
  .raddr2(),
  .rdata2()
);

/*********** End of your code *******************/

// Internal signals


endmodule