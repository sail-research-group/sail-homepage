// Module: CPU
// Description: Top-level module for the RISKing Processor CPU
// Lab 3 note: In Lab 3, you will implement the CPU module with FSM, 
// datapath and instruction decoder. The FSM should constantly fetch 
// instruction from outside, which is the switches. The output of
// the CPU is the datapath_out, that goes to the 7 segment display.

module CPU (
  input logic clk,     
  input logic rst,
  input logic [15:0] switches,
  output logic [15:0] data_bus,
  output logic [3:0] status_out,
  output logic fetch,
  //debugging signals
  output logic [2:0] state_out,
  output logic err
);

/*********** Fill your code below *****************/

// Instantiate datapath
datapath DP_inst (
  .clk(),
  .rst(),
  .vsel(),
  .asel(),
  .bsel(),
  .ALUop(),
  .shift_op(),
  .loady(),
  .loads(),
  .rf_waddr(),
  .rf_wen(),
  .rf_raddra(),
  .rf_raddrb(),
  .datapath_in(),
  .sximm8(),
  .tximm8(),
  .pc_plus1(16'b0), // not used in lab 3
  .sximm5(),
  .status_out(),
  .datapath_out()
);



// FSM for control signal generation
FSM FSM_inst (
  .clk(),
  .rst(),
  // debugging signals, you can use them to debug your FSM with LED
  // .state_out(state_out),
  // .err_flag(err),
  .ir_opcode(),
  .vsel(),
  .asel(),
  .bsel(),
  .loady(),
  .loads(),
  .rf_wen(),
  .arith_sel(),
  .dp_gate(),
  .load_ir()
);

/*********** End of your code *******************/



endmodule