// Module: FSM
// Description: FSM for RISKing Processor
// LAB 3 note: In Lab 3, you will implement the FSM module to generate control signals for the datapath.
// In LAB 3, you only need to implement the FSM to support the R-type instructions, I-type instructions (ADDI, SUBI) and immediate load instructions(LDI, LUI). You don't need to care about program counter and mem\ory in Lab 3. You will implement Memory system and PC in Lab 4, and you will implement the jump and branch instructions in Lab 5.
// R-type instructions: ADD, SUB, ADDC, SUBC, AND, ANDBB, OR, ORBB
// I-type instructions: ADDI, SUBI. (Note: RISKing arch naturally supports other I-type instructions like ANDI, ORI, etc. But in ISP, we ignore them.)
// Immediate load instructions: LDI, LUI

module FSM(
  input logic clk,
  input logic rst,
  // Debuging outputs
  output logic [2:0] state_out,
  output logic err_flag,
  // Instruction fields
  input logic [4:0] ir_opcode,
  // Datapath control signals
  output logic [1:0] vsel,  // Data input select
  output logic asel,        // A operand select
  output logic bsel,        // B operand select
  output logic loady,
  output logic loads,
  output logic rf_wen,
  // CPU control signals
  output logic arith_sel,
  output logic dp_gate,
  output logic load_ir
);

/*********** Fill your code below *****************/




/*********** End of your code *******************/


endmodule
