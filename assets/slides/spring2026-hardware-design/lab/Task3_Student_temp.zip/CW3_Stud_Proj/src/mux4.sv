//Module: mux4
//Description: 4-to-1 multiplexer

module mux4 #(parameter WIDTH = 16) (
  input logic [WIDTH-1:0] in0,   // Input 0
  input logic [WIDTH-1:0] in1,   // Input 1
  input logic [WIDTH-1:0] in2,   // Input 2
  input logic [WIDTH-1:0] in3,   // Input 3
  input logic [1:0]       sel,    // Select signal
  output logic [WIDTH-1:0] out    // Output
);

  always_comb begin
    case (sel)
      2'b00: out = in0;
      2'b01: out = in1;
      2'b10: out = in2;
      2'b11: out = in3;
      default: out = '0; // Default case to avoid latches
    endcase
  end

endmodule