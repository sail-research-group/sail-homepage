// Module: mux2
// Description: 2-to-1 Multiplexer for RISKing Processor
module mux2 #(
  parameter WIDTH = 16          // Width of the data bus
) (
  input logic [WIDTH-1:0] in0,  // Input 0
  input logic [WIDTH-1:0] in1,  // Input 1
  input logic             sel,   // Select signal
  output logic [WIDTH-1:0] out   // Output
);

  // Combinational logic for 2-to-1 multiplexer
  always_comb begin
    if (sel) begin
      out = in1;
    end else begin
      out = in0;
    end
  end 

endmodule