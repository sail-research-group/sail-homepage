// Module: reg_en
// Description: Register with enable for RISKing Processor
///////////////////////////////////////////////////////////////// 

module reg_en #(
  parameter WIDTH = 16
) (
  input logic        clk,       // Clock input
  input logic        rst,       // Reset signal
  input logic        en,        // Enable signal
  input logic [WIDTH-1:0] data_in,   // Data input
  output logic [WIDTH-1:0] data_out   // Data output
);

  // Internal register to hold the value
  logic [WIDTH-1:0] register;
  // Sequential logic for register with enable
  always_ff @(posedge clk or posedge rst) begin
    if (rst) begin
      register <= {WIDTH{1'b0}}; // Reset register to 0
    end else if (en) begin
      register <= data_in; // Load data if enabled
    end else begin
      register <= register; // Hold the current value
    end
  end

  // Continuous assignment to output
  assign data_out = register;

endmodule
