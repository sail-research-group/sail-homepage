`timescale 1ns/1ps

module seq_detect_tb;

    logic clk = 0;
    always #5 clk = ~clk; // 100 MHz

    logic reset, step, din;
    logic match;
    logic [2:0] state_dbg;

    seq_detect_1011_moore dut (
        .clk(clk),
        .reset(reset),
        .step(step),
        .din(din),
        .match(match),
        .state_dbg(state_dbg)
    );

    task automatic push_bit(input logic b);
        begin
            din  = b;
            step = 1;
            @(posedge clk);
            step = 0;
            @(posedge clk);
        end
    endtask

    initial begin
        reset = 1;
        step  = 0;
        din   = 0;

        repeat (2) @(posedge clk);
        reset = 0;

        // Stream: 1 0 1 1  (detect)
        push_bit(1);
        push_bit(0);
        push_bit(1);
        push_bit(1);

        // Overlap continuation: 0 1 1
        push_bit(0);
        push_bit(1);
        push_bit(1);

        #50 $finish;
    end

endmodule
