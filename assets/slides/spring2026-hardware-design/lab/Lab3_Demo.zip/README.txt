Lab 3 FSM (updated) - Moore 1011 sequence detector with debounced STEP and RESET.

Vivado:
- Add Design Sources: top.sv, seq_detect_1011_moore.sv, debounce_onepulse.sv, seg7display.v
- Add Simulation Sources: seq_detect_tb.sv
- Add Constraints: lab3_basys3.xdc
- Set top for FPGA: top
- Build bitstream and program Basys 3.

Board:
- SW0  = din (input bit)
- BTNU = step (debounced, one pulse per press)
- BTNC = reset (debounced, synchronous)
- LED0 = match
- LED[3:1] = state (0..4)
- 7-seg shows: hist (rightmost), state, match
