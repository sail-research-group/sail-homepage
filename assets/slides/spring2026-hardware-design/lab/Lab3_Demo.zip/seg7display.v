`timescale 1ns/1ps

module seg7display(
    input  wire [15:0] x_l,     // {hex3, hex2, hex1, hex0}
    input  wire        clk,
    input  wire        reset,
    output reg  [6:0]  a_to_g,   // {g,f,e,d,c,b,a} active-low
    output reg  [3:0]  an_l,     // active-low digit enables
    output wire        dp_l      // active-low decimal point
);

    assign dp_l = 1'b1; // off

    reg [19:0] refresh_cnt;
    always @(posedge clk) begin
        if (reset) refresh_cnt <= 20'd0;
        else       refresh_cnt <= refresh_cnt + 20'd1;
    end

    wire [1:0] sel = refresh_cnt[19:18];

    reg [3:0] nibble;
    always @(*) begin
        nibble = 4'h0;
        an_l   = 4'b1111;
        case (sel)
            2'd0: begin nibble = x_l[3:0];   an_l = 4'b1110; end
            2'd1: begin nibble = x_l[7:4];   an_l = 4'b1101; end
            2'd2: begin nibble = x_l[11:8];  an_l = 4'b1011; end
            2'd3: begin nibble = x_l[15:12]; an_l = 4'b0111; end
        endcase
    end

    always @(*) begin
        case (nibble)
            4'h0: a_to_g = 7'b1000000;
            4'h1: a_to_g = 7'b1111001;
            4'h2: a_to_g = 7'b0100100;
            4'h3: a_to_g = 7'b0110000;
            4'h4: a_to_g = 7'b0011001;
            4'h5: a_to_g = 7'b0010010;
            4'h6: a_to_g = 7'b0000010;
            4'h7: a_to_g = 7'b1111000;
            4'h8: a_to_g = 7'b0000000;
            4'h9: a_to_g = 7'b0010000;
            4'hA: a_to_g = 7'b0001000;
            4'hB: a_to_g = 7'b0000011;
            4'hC: a_to_g = 7'b1000110;
            4'hD: a_to_g = 7'b0100001;
            4'hE: a_to_g = 7'b0000110;
            4'hF: a_to_g = 7'b0001110;
            default: a_to_g = 7'b1111111;
        endcase
    end

endmodule
