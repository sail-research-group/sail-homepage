`timescale 1ns/1ps

module debounce_onepulse #(
    parameter int CLK_HZ       = 100_000_000,
    parameter int DEBOUNCE_MS  = 20            // 10–25ms typical
)(
    input  logic clk,
    input  logic btn_in,        // raw button input (async, bouncy)
    output logic debounced,     // stable button level
    output logic pressed_pulse  // 1-cycle pulse on rising edge of debounced
);

    // 1) Synchronise into clk domain (2 FFs)
    logic meta, sync;
    always_ff @(posedge clk) begin
        meta <= btn_in;
        sync <= meta;
    end

    // 2) Debounce using a counter: input must stay unchanged long enough
    localparam int COUNT_MAX = (CLK_HZ/1000) * DEBOUNCE_MS;
    logic [$clog2(COUNT_MAX+1)-1:0] cnt = '0;
    logic stable_level = 1'b0;

    always_ff @(posedge clk) begin
        if (sync == stable_level) begin
            cnt <= '0;
        end else begin
            if (cnt == COUNT_MAX[$clog2(COUNT_MAX+1)-1:0]) begin
                stable_level <= sync;
                cnt <= '0;
            end else begin
                cnt <= cnt + 1'b1;
            end
        end
    end

    // 3) One-pulse on rising edge of debounced
    logic debounced_prev = 1'b0;
    always_ff @(posedge clk) begin
        debounced      <= stable_level;
        debounced_prev <= debounced;
    end

    always_comb begin
        pressed_pulse = debounced & ~debounced_prev;
    end

endmodule
