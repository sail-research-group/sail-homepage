`timescale 1ns/1ps

module seq_detect_1011_moore (
    input  logic       clk,
    input  logic       reset,     // synchronous reset
    input  logic       step,      // advance FSM when step=1 (clock enable)
    input  logic       din,       // serial input bit
    output logic       match,     // Moore output: 1 only in match state
    output logic [2:0] state_dbg  // debug view of current state
);

    // State encoding (localparam) - 5 states, 3 bits is enough
    // Meaning: how much of "1011" we have matched so far.
    localparam logic [2:0] S0 = 3'd0; // matched nothing
    localparam logic [2:0] S1 = 3'd1; // matched "1"
    localparam logic [2:0] S2 = 3'd2; // matched "10"
    localparam logic [2:0] S3 = 3'd3; // matched "101"
    localparam logic [2:0] S4 = 3'd4; // matched "1011" (match)

    logic [2:0] state, next_state;

    // 1) State register (sequential)
    // - synchronous reset
    // - advances only on step (enable)
    always_ff @(posedge clk) begin
        if (reset) begin
            state <= S0;
        end else if (step) begin
            state <= next_state;
        end
    end

    // 2) Next-state logic (combinational)
    // Overlap-capable 1011 detector.
    always_comb begin
        next_state = state; // default prevents latches

        unique case (state)
            S0: next_state = (din) ? S1 : S0;
            S1: next_state = (din) ? S1 : S2;
            S2: next_state = (din) ? S3 : S0;
            S3: next_state = (din) ? S4 : S2;
            S4: next_state = (din) ? S1 : S2;
            default: next_state = S0;
        endcase
    end

    // 3) Output logic (Moore)
    always_comb begin
        match     = (state == S4);
        state_dbg = state;
    end

endmodule
