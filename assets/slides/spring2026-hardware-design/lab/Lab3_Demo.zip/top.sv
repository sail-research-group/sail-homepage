`timescale 1ns/1ps

module top(
    input  wire        clk,                 // 100 MHz Basys3 clock
    input  wire [15:0]  SW,
    input  wire        BTNL, BTNR, BTNU, BTND, BTNC,
    output wire        CA, CB, CC, CD, CE, CF, CG, DP,
    output wire [3:0]  AN,
    output wire [15:0] LED
);

    // Debounce reset (BTNC) -> stable synchronous reset level
    logic reset_level;
    logic reset_pulse_unused;
    debounce_onepulse #(
        .CLK_HZ(100_000_000),
        .DEBOUNCE_MS(20)
    ) db_reset (
        .clk(clk),
        .btn_in(BTNC),
        .debounced(reset_level),
        .pressed_pulse(reset_pulse_unused)
    );
    wire reset_sync = reset_level;

    // Debounce step (BTNU) -> one clean pulse per press
    logic step_level;
    wire  step_pulse;
    debounce_onepulse #(
        .CLK_HZ(100_000_000),
        .DEBOUNCE_MS(20)
    ) db_step (
        .clk(clk),
        .btn_in(BTNU),
        .debounced(step_level),
        .pressed_pulse(step_pulse)
    );
    wire step = step_pulse;

    // Input bit from SW0
    wire din = SW[0];

    // FSM
    logic match;
    logic [2:0] state_dbg;
    seq_detect_1011_moore dut (
        .clk      (clk),
        .reset    (reset_sync),
        .step     (step),
        .din      (din),
        .match    (match),
        .state_dbg(state_dbg)
    );

    // History shift register (last 4 bits)
    logic [3:0] hist;
    always_ff @(posedge clk) begin
        if (reset_sync) hist <= 4'b0000;
        else if (step)  hist <= {hist[2:0], din};
    end

    // LEDs
    assign LED[0]    = match;
    assign LED[3:1]  = state_dbg;
    assign LED[15:4] = 12'b0;

    // 7-seg debug: hist/state/match
    wire [3:0] hex0 = hist;
    wire [3:0] hex1 = {1'b0, state_dbg};
    wire [3:0] hex2 = {3'b0, match};
    wire [3:0] hex3 = 4'h0;

    wire [6:0] a_to_g;
    wire [3:0] an_l;
    wire       dp_l;

    seg7display seg7_inst (
        .x_l    ({hex3, hex2, hex1, hex0}),
        .clk    (clk),
        .reset  (reset_sync),
        .a_to_g (a_to_g),
        .an_l   (an_l),
        .dp_l   (dp_l)
    );

    assign {CG, CF, CE, CD, CC, CB, CA} = a_to_g;
    assign AN = an_l;
    assign DP = dp_l;

endmodule
