// Auther: Zihao Pu
// Date: 2025-12-11
// Description: top module for the 4-bit full adder
// ----------------------------------
// Input: a[3:0], b[3:0], cin
// a[3:0] slider 0-3
// b[3:0] slider 4-7
// cin slider 8
/*

    <----------------------- Input Switches -----------------------> 
___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  
| |  | |  | |  | |  | |  | |  | |  | |  | |  | |  | |  | |  | |  | |  | |  | |  
|●|  |●|  |●|  |●|  |●|  |●|  |●|  |●|  |●|  |●|  |●|  |●|  |●|  |●|  |●|  |●|   
~~~  ~~~  ~~~  ~~~  ~~~  ~~~  ~~~  ~~~  ~~~  ~~~  ~~~  ~~~  ~~~  ~~~  ~~~  ~~~  
 15   14   13   12   11   10   9    8    7    6    5    4    3    2    1    0
                                   cin  b[3] b[2] b[1] b[0] a[3] a[2] a[1] a[0]

*/
// ---
// 7 segment display:
/*

      --0--           --0--           --0--           --0--           
     |     |         |     |         |     |         |     |          
     5     1         5     1         5     1         5     1        
     |     |         |     |         |     |         |     |        
      --6--           --6--           --6--           --6--       
     |     |         |     |         |     |         |     |        
     4     2         4     2         4     2         4     2        
     |     |         |     |         |     |         |     |      
      --3--           --3--           --3--           --3--   
        |               |               |               |      
      Carry            Sum              B               A     
*/



module top(
  input       clk,        // Clock input
  input [15:0] sw,          // Input switches
  output CA, CB, CC, CD, CE, CF, CG, DP, // 7-segment display segments
  output [3:0]  AN,          // 7-segment display anodes
  output [15:0] led       // LED outputs to show the result
);

//Wires and signals
wire [3:0] a;
wire [3:0] b;
wire       cin;
wire [3:0] sum;
wire       cout;

// Assign inputs from switches
assign a   = sw[3:0];
assign b   = sw[7:4];
assign cin = sw[8];

assign led = {7'b0, cin, b, a}; // Display inputs on LEDs


// Instantiate seg7 display module
seg7display u0 (
  .x_l({3'b0, cout, sum, b, a}), // Lower 16 bits: cout, sum, b, a
  .clk(clk),
  .reset(1'b0),
  .a_to_g({CG, CF, CE, CD, CC, CB, CA}),
  .an_l(AN),
  .dp_l(DP)  // Decimal point for least significant digit
);


// Instantiate full adder 4 bit module
full_adder_4bit u1 (
  .a(a),
  .b(b),
  .cin(cin),
  .sum(sum),
  .cout(cout)
);

endmodule