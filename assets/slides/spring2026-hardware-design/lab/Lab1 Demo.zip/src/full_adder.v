// Auther: Zihao Pu
// Date: 2025-12-11
// Description: 1-bit Full Adder

`timescale 1ns/1ps

// Full Adder Circuit Diagram:
//
//     a ─────┬─────────XOR────┬──────XOR── sum
//     b ─────┤                │
//            └─ ab_xor        │
//                            cin
//
//     a ─────┬─────────AND────┐
//     b ─────┤                ├──OR── cout
//            └─ ab_and        │
//                           AND
//            ab_xor ──┬───────┘
//            cin ─────┘
//            (axor_cin_and)

module full_adder (
    input  wire a,        // First input bit
    input  wire b,        // Second input bit
    input  wire cin,      // Carry-in bit
    output wire sum,      // Sum output bit
    output wire cout      // Carry-out bit
);

    // Internal signals for intermediate calculations
    wire ab_xor;         // XOR of a and b
    wire ab_and;         // AND of a and b
    wire axor_cin_and;   // AND of (a XOR b) and cin

    // Calculate sum as XOR of a, b, and cin
    assign ab_xor = a ^ b;
    assign sum = ab_xor ^ cin;

    // Calculate carry-out as OR of (a AND b) and ((a XOR b) AND cin)
    assign ab_and = a & b;
    assign axor_cin_and = ab_xor & cin;
    assign cout = ab_and | axor_cin_and;

endmodule