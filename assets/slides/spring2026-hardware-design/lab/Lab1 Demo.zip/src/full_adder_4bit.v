// Auther: Zihao Pu
// Date: 2025-12-11
// Description: 4-bit full adder using 1-bit full adders

`timescale 1ns/1ps

module full_adder_4bit(
    input  wire [3:0] a,        // First 4-bit input
    input  wire [3:0] b,        // Second 4-bit input
    input  wire       cin,      // Carry-in bit
    output wire [3:0] sum,      // 4-bit Sum output
    output wire       cout      // Carry-out bit
);

    // Internal carry signals between the full adders
    wire c1, c2, c3;

    // Instantiate four 1-bit full adders
    full_adder fa0 (.a(a[0]),.b(b[0]),.cin(cin),.sum(sum[0]),.cout(c1));
    full_adder fa1 (.a(a[1]),.b(b[1]),.cin(c1),.sum(sum[1]),.cout(c2));
    full_adder fa2 (.a(a[2]),.b(b[2]),.cin(c2),.sum(sum[2]),.cout(c3));
    full_adder fa3 (.a(a[3]),.b(b[3]),.cin(c3),.sum(sum[3]),.cout(cout));
endmodule