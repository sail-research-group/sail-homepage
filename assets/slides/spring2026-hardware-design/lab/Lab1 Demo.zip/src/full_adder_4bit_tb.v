// Auther: Zihao Pu
// Date: 2025-12-11
// Description: 4-bit full adder using 1-bit full adders testbench

`timescale 1ns/1ps

module full_adder_4bit_tb;

// Testbench signals
reg [3:0] a;
reg [3:0] b;
reg       cin;
wire [3:0] sum;
wire       cout;

wire [3:0]  expected_sum;
wire       expected_cout;

assign {expected_cout, expected_sum} = a + b + cin;

// Instantiate the 4-bit full adder module
full_adder_4bit dut (.a(a),.b(b),.cin(cin),.sum(sum),.cout(cout));

// Test procedure
initial begin
    // Monitor changes
    $monitor("Time=%0t | a=%b b=%b cin=%b | sum=%b cout=%b", $time, a, b, cin, sum, cout);
    $dumpfile("sim.vcd");
    $dumpvars(0, full_adder_4bit_tb);
    // Test various combinations of inputs
    a = 4'b0000; b = 4'b0000; cin = 0; #10; 
    a = 4'b0001; b = 4'b0010; cin = 0; #10; 
    a = 4'b0011; b = 4'b0101; cin = 1; #10; 
    a = 4'b1111; b = 4'b0001; cin = 0; #10; 
    a = 4'b1010; b = 4'b0101; cin = 1; #10; 
    a = 4'b1111; b = 4'b1111; cin = 1; #10; 

    // Finish simulation
    $finish;
end


endmodule
