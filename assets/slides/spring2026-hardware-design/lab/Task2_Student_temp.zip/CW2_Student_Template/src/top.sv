// Top module that interfaces the ALU and BASYS3 board components
// BTN mapping
//          BTNT
//  BTNL    BTNC    BTNR
//          BTND
/////////////////////////////////////////////////////////////////



`timescale 1ns / 1ps

module top(
  input       clk,                          // Clock input
  input [15:0] SW,                          // Input switches
  input       BTNL, BTNR, BTNU, BTND, BTNC, // Input buttons

  output CA, CB, CC, CD, CE, CF, CG, DP, // 7-segment display segments
  output [3:0]  AN,          // 7-segment display anodes
  output [15:0] LED       // LED outputs to show the result
);

// Internal Signals
logic       rst;            // Reset signal
logic [15:0] datapath_out;  // Data output from the datapath

// Clock mimicing signal for testing
logic clk_datapath, clk_imm, clk_regfile_ctrl, clk_dp_ctrl;
assign rst = BTNC; // Use the center button as reset
assign clk_datapath = BTNU; // Use the up button as the clock for the datapath
assign clk_imm = BTNR; // Use the right button as the clock for loading immediate data
assign clk_regfile_ctrl = BTND; // Use the down button as the clock for loading register file control signals
assign clk_dp_ctrl = BTNL; // Use the left button as the clock for loading datapath control signals

// Registers to hold the control signals for the datapath
logic [15:0] imm_data_reg, regfile_ctrl_reg, dp_ctrl_reg;
always_ff @(posedge clk_imm or posedge rst) begin
    if (rst) imm_data_reg <= 16'b0;
    else imm_data_reg <= SW; // Load immediate data from switches
end

always_ff @(posedge clk_regfile_ctrl or posedge rst) begin
    if (rst) regfile_ctrl_reg <= 16'b0;
    else regfile_ctrl_reg <= SW; // Load register file control signals from switches
end

always_ff @(posedge clk_dp_ctrl or posedge rst) begin
    if (rst) dp_ctrl_reg <= 16'b0;
    else dp_ctrl_reg <= SW; // Load datapath control signals from switches
end

// Assign control signals to the datapath

// imm data for ALU input
//----------------------------------------------
// | 15 14 13 | 12 11 10 9 8 | 7 6 5 4 3 2 1 0 |
//----------------------------------------------
// |          |     imm5     |       imm8      |
//----------------------------------------------
logic [15:0] sximm8, sximm5;

assign sximm8 = {{8{imm_data_reg[7]}}, imm_data_reg[7:0]}; // Sign-extend the lower 8 bits
assign sximm5 = {{11{imm_data_reg[12]}}, imm_data_reg[12:8]}; // Sign-extend the upper 5 bits

// Register file control signals
//------------------------------------------------------
// | 15 14 13 12 11 10 |  9  | 8 7 6 | 5 4 3  | 2 1 0  |
//------------------------------------------------------
// |                   | wen | waddr | raddrb | raddra |
//------------------------------------------------------
logic [2:0] rf_waddr, rf_raddra, rf_raddrb;
logic rf_wen;
assign rf_wen = regfile_ctrl_reg[9];
assign rf_waddr = regfile_ctrl_reg[8:6];
assign rf_raddrb = regfile_ctrl_reg[5:3];
assign rf_raddra = regfile_ctrl_reg[2:0];

// Datapath control signals
//----------------------------------------------------------------
//| 15 14 13 12 11 10| 9  | 8  | 7  |  6  |  5  |  4  3  | 2 1 0 |
//----------------------------------------------------------------
//|       NA         |vsel|asel|bsel|loady|loads|shift_op| ALUop |
//----------------------------------------------------------------
logic vsel, asel, bsel, loady, loads;
logic [1:0] shift_op;
logic [2:0] ALUop;
assign vsel = dp_ctrl_reg[9];
assign asel = dp_ctrl_reg[8];
assign bsel = dp_ctrl_reg[7];
assign loady = dp_ctrl_reg[6];
assign loads = dp_ctrl_reg[5];
assign shift_op = dp_ctrl_reg[4:3];
assign ALUop = dp_ctrl_reg[2:0];

// Datapath implementation
datapath DP_inst (
  .clk(clk_datapath),
  .rst(rst),
  .vsel(vsel),
  .asel(asel),
  .bsel(bsel),
  .ALUop(ALUop),
  .shift_op(shift_op),
  .loady(loady),
  .loads(loads),
  .rf_waddr(rf_waddr),
  .rf_wen(rf_wen),
  .rf_raddra(rf_raddra),
  .rf_raddrb(rf_raddrb),
  .datapath_in(datapath_out), // Feedback for testing
  .sximm8(sximm8),
  .sximm5(sximm5),
  .status_out(LED[3:0]), // Output status flags to the upper 4 LEDs
  .datapath_out(datapath_out)
);

// Output to 7segment display
seg7display #(
  .MODULES(1)
) U_DISPLAY (
  .x_l(datapath_out),
  .x_h(16'b0),
  .clk(clk),
  .reset(rst),
  .a_to_g ({CG, CF, CE, CD, CC, CB, CA}),
  .an_l(AN),
  .an_h(),
  .dp_l(DP),
  .dp_h()
);

endmodule