// Module: shifter
// Description: Shifter for RISKing Processor
// Opcodes:
// 00 - No shift
// 01 - Logical left shift
// 10 - Logical right shift
// 11 - Arithmetic right shift
/////////////////////////////////////////////////////////////////

module shifter (
  input logic [15:0] in_data,    // Input data to be shifted
  input logic [1:0]  shift_op,   // Shift operation code
  output logic [15:0] out_data    // Shifted output data
);

// Combinational logic for shifter
// Note: No clock needed. Shifter is fully combinational
/*********** Fill your code below *****************/



/*********** End of your code *******************/

endmodule
