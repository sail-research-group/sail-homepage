// Module: datapath
// Description: Datapath for RISKing Processor


module datapath (
  input logic        clk,         // Clock input
  input logic        rst,         // Reset signal

  //datapath control signals
  input logic        vsel,        // Data input select
  input logic        asel,        // A operand select
  input logic        bsel,        // B operand select
  input logic [2:0]  ALUop,       // ALU operation code
  input logic [1:0]  shift_op,    // Shift operation code
  input logic        loady,       // Load Y register: Results from ALU
  input logic        loads,       // Load S register: Status flags from ALU
  // Register file control signals
  input logic [2:0]  rf_waddr,    // Write register number
  input logic        rf_wen,      // Write enable signal
  input logic [2:0]  rf_raddra,   // Read register a number
  input logic [2:0]  rf_raddrb,   // Read register b number
  // Data input
  input logic [15:0] datapath_in, // 16-bit data input
  input logic [15:0] sximm8,      // Sign-extended immediate value (from instruction)
  input logic [15:0] sximm5,      // Sign-extended immediate value (from instruction)

  // Data output
  output logic [3:0]  status_out,    // Status flags output
  output logic [15:0] datapath_out      // 16-bit data output
);

// Register File
logic [15:0] data_in;
logic [15:0] rf_outa, rf_outb;

// Register file instance provided for you
// Do not change! Autograder will check che values in the register file
// so it must be instantiated as shown below.
regfile_2p RF_inst (
  .clk(clk),
  .rst(rst),
  .wen(rf_wen),
  .waddr(rf_waddr),
  .wdata(data_in),
  .raddr1(rf_raddra),
  .rdata1(rf_outa),
  .raddr2(rf_raddrb),
  .rdata2(rf_outb)
);

/*********** Fill your code below *****************/



/*********** End of your code *******************/

endmodule