# HAD 2026 Coursework LAB 2 Instruction

In this lab, you are going to implement the datapath for RISKing CPU. We have provided the project template, testbench and `regfile_2p.sv` as a starting point. You are required to:

1. Migrate the `ALU` and `shifter` designed in _TASK 1_ to this project.
2. Fill the `datapath.sv` as described in `TASK 2` slides.
3. Run simulation with provided testbench: `datapath_tb.sv`. You can edit the testbench and add your own test cases. You should see `All Test Cases Passed!` in `Tcl Console` after running the simulation.
4. Download project to `BASYS3`. You can use the pushbuttons and switches to operate the datapath as shown in the lab.