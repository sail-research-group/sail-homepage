// testbench for datapath modules
// Author: Zihao Pu
// Date: 2026-02-01


`timescale 1ns/1ps

module datapath_tb;

// Internal Signals
logic clk;
logic rst;
// Control signals
logic vsel, asel, bsel, loady, loads;
logic [2:0] ALUop;
logic [1:0] shift_op;

// Register file control signals
logic [2:0] rf_raddra, rf_raddrb, rf_waddr;
logic rf_wen;

// Data signals
logic [15:0] datapath_out;
logic [15:0] sximm8, sximm5;
logic Z, N, V, C;// status flags

// Error check signal
logic err;
integer err_cnt;

// Register numbers and opcodes
parameter R0 = 3'b000;
parameter R1 = 3'b001;
parameter R2 = 3'b010;
parameter R3 = 3'b011;
parameter R4 = 3'b100;
parameter R5 = 3'b101;
parameter R6 = 3'b110;
parameter R7 = 3'b111;

parameter ADD   = 3'b000;
parameter SUB   = 3'b001;
parameter ADDC  = 3'b010;
parameter SUBC  = 3'b011;
parameter AND   = 3'b100;
parameter ANDBB = 3'b101;
parameter OR    = 3'b110;
parameter ORBB = 3'b111;

parameter NOSHIFT = 2'b00;
parameter LSL1    = 2'b01;
parameter LSR1    = 2'b10;
parameter ASR1    = 2'b11;


// Instantiate the datapath
datapath DUT (
  .clk(clk),
  .rst(rst),
  .vsel(vsel),
  .asel(asel),
  .bsel(bsel),
  .ALUop(ALUop),
  .shift_op(shift_op),
  .loady(loady),
  .loads(loads),
  .rf_waddr(rf_waddr),
  .rf_wen(rf_wen),
  .rf_raddra(rf_raddra),
  .rf_raddrb(rf_raddrb),
  .datapath_in(datapath_out), // write back datapath_out to datapath_in for testing
  .sximm8(sximm8),            // Can be driven by tasks
  .sximm5(sximm5),            // Can be driven by tasks
  .status_out({Z, N, V, C}),
  .datapath_out(datapath_out)
);

// Clock generation
initial begin
  clk = 0;
  forever #5 clk = ~clk; // 10ns clock period 
end

// Testbench
integer i;
integer j;
integer fd;

initial begin
  // Dump waveforms
  // $dumpfile("./build/sim.vcd");
  $dumpvars(0, datapath_tb);
  // fd = $fopen("./build/report.log","w");
  err = 0;
  err_cnt = 0;

  // Reset DUT
  reset_dut();

  /**************************************************/
  /****** Test Case 1: Test Datapath_in Write *******/
  /**************************************************/
  $display( "Info: Test Case 1: Datapath_in Write");
  // Write a value to register file
  for (i = 0; i < 8; i = i + 1) begin
    movi(i, 16'h0000 + i); // Move immediate value to register Ri
  end

  // Check if the values are correctly written to the registers
  for (i = 0; i < 8; i = i + 1) begin
    check_register(i, 16'h0000 + i);
  end

  // Write different values to regfile
  for (i=0; i < 8; i = i + 1) begin
    movi(i, 16'h00FF - i); // Move immediate value to register Ri
  end

  // Check if the new values are correctly written to the registers
  for (i = 0; i < 8; i = i + 1) begin
    check_register(i, 16'h00FF - i);
  end

  if (err) begin
    err_cnt = err_cnt + 1;
    $display("Error: Test Case 1 Failed.");
  end else begin
    $display("Info:  Test Case 1 Passed!");
  end

  /*********************************************************/
  /****** Test Case 2: Test ALU and Shift Operations *******/
  /*********************************************************/
  $display("\nInfo: Test Case 2: ALU and Shift Operations");
  err = 0; // Reset error flag for new test case
  reset_dut(); // Reset before starting new test case
  // Load some values into registers for testing
  // R0 is 0 by default
  movi(R1, 16'h000F); // R1 = 0x000F
  movi(R2, 16'h00F0); // R2 = 0x00F0
  // Test ADD operation: R3 = R1 + R2
  arithmatic_op(ADD, R3, R1, NOSHIFT, R2);
  check_register(R3, 16'h00FF); // Expect R3 = 0x00FF
  // Test SUB operation: R4 = R2 - R1
  arithmatic_op(SUB, R4, R2, NOSHIFT, R1);
  check_register(R4, 16'h00E1); // Expect R4 = 0x00E1
  // Test AND operation: R5 = R1 & R2
  arithmatic_op(AND, R5, R1, NOSHIFT, R2);
  check_register(R5, 16'h0000); // Expect R5 = 0x0000
  // Test OR operation: R6 = R1 | R2
  arithmatic_op(OR, R6, R1, NOSHIFT, R2);
  check_register(R6, 16'h00FF); // Expect R6 = 0x00FF
  // Test LSL1 operation: R7 = R1 << 1
  arithmatic_op(ADD, R7, R0, LSL1, R1); // Use ADD with shift to perform LSL1
  check_register(R7, 16'h001E); // Expect R7 = 0x001E (0x000F << 1)
  // Test LSR1 operation: R7 = R1 >> 1
  arithmatic_op(ADD, R7, R0, LSR1, R1); // Use ADD with shift to perform LSR1
  check_register(R7, 16'h0007); // Expect R7 = 0x0007 (0x000F >> 1)
  // Test ASR1 operation: R7 = R1 >>> 1 (arithmetic shift)
  arithmatic_op(ADD, R7, R0, ASR1, R1); // Use ADD with shift to perform ASR1
  check_register(R7, 16'h0007); // Expect R7 = 0x0007 (0x000F >>> 1) 

  if(err) begin
    err_cnt = err_cnt + 1;
    $display("Error: Test Case 2 Failed.");
  end else begin
    $display("Info: Test Case 2 Passed!");
  end

  /*********************************************************/
  /****** Test Case 3: Test ALU Operations with Carry ******/
  /******       32-bit Addition and Subtraction      *******/
  /*********************************************************/
  $display("\nInfo: Test Case 3: ALU Operations with Carry/Borrow for 32-bit Addition and Subtraction");
  err = 0; // Reset error flag for new test case
  reset_dut(); // Reset before starting new test case
  // Load values into registers for testing
  // R0 is 0 by default
  // R1 is MSB for number A, R2 is LSB for number A
  // R3 is MSB for number B, R4 is LSB for number B
  // C = A + B, where R5 is MSB for result, R6 is LSB for result
  // Try 0x12345678 + 0xAAAAAAAA = 0xBCDF0122
  movi(R1, 16'h1234); // R1 = 0x1234
  movi(R2, 16'h5678); // R2 = 0x5678
  movi(R3, 16'hAAAA); // R3 = 0xAAAA
  movi(R4, 16'hAAAA); // R4 = 0xAAAA
  // Perform LSB addition: R6 = R2 + R4
  arithmatic_op(ADD, R6, R2, NOSHIFT, R4);
  check_register(R6, 16'h0122); // Expect R6 = 0x0122 (0x5678 + 0xAAAA = 0x01112, LSB is 0x0122 with carry)
  // Perform MSB addition with carry: R5 = R1 + R3 + carry
  arithmatic_op(ADDC, R5, R1, NOSHIFT, R3); // Use ADDC to include carry from previous addition
  check_register(R5, 16'hBCDF); // Expect R5 = 0xBCDF (0x1234 + 0xAAAA + carry = 0xBCDF) 

  // Subtract with borrow
  // Try 0x12345678 - 0xAAAAAAAA = 0x6789ABCE
  arithmatic_op(SUB, R6, R2, NOSHIFT, R4); // Perform LSB subtraction: R6 = R2 - R4
  arithmatic_op(SUBC, R5, R1, NOSHIFT, R3); // Perform MSB subtraction with borrow: R5 = R1 - R3 - borrow
  check_register(R6, 16'hABCE); // Expect R6 = 0xABCE (0x5678 - 0xAAAA = 0xFFFFABCE, LSB is 0xABCE with borrow)
  check_register(R5, 16'h6789); // Expect R5 = 0x6789 (0x1234 - 0xAAAA - borrow = 0x6789)

  if(err) begin
    err_cnt = err_cnt + 1;
    $display("Error: Test Case 3 Failed.");
  end else begin
    $display("Info: Test Case 3 Passed!");
  end


  /*************************************************************/
  /****** Test Case 4: Test ALU Operations with Immediate ******/
  /*************************************************************/
  $display("\nInfo: Test Case 4: ALU Operations with Immediate");
  err = 0; // Reset error flag for new test case
  reset_dut(); // Reset before starting new test case
  // Load a value into R1 for testing
  movi(R1, 16'h000A); // R1 = 0x000A
  // Test ADD operation with immediate: R2 = R1 + 5
  arithmatic_op_imm(ADD, R2, R1, 16'h0005); // Use 5 as immediate value
  check_register(R2, 16'h000F); // Expect R2 = 0x000F
  // Test SUB operation with immediate: R3 = R1 - 3
  arithmatic_op_imm(SUB, R3, R1, 16'h0003); // Use 3 as immediate value
  check_register(R3, 16'h0007); // Expect R3 = 0x0007
  // Test AND operation with immediate: R4 = R1 & 0x000F
  arithmatic_op_imm(AND, R4, R1, 16'h000F); // Use 0x000F as immediate value
  check_register(R4, 16'h000A); // Expect R4 = 0x000A
  // Test OR operation with immediate: R5 = R1 | 0x0005
  arithmatic_op_imm(OR, R5, R1, 16'h0005); // Use 0x0005 as immediate value
  check_register(R5, 16'h000F); // Expect R5 = 0x000F

  if(err) begin
    err_cnt = err_cnt + 1;
    $display("Error: Test Case 4 Failed.");
  end else begin
    $display("Info: Test Case 4 Passed!");
  end



  // Final Test Result
  if (err_cnt == 0) begin
    $display("All Test Cases Passed!");
  end else begin
    $display("Error: Some Test Cases Failed.");
  end
  $display("Info: Total Failed Test Cases: %0d", err_cnt);
  #20;
  // Finish simulation
  $fclose(fd);
  $finish;
end


/***********************/
/* Tasks and Functions */
/***********************/

task automatic reset_dut();
  begin
    // Initialize signals
    rst = 1;
    vsel = 0;
    asel = 0;
    bsel = 0;
    ALUop = 3'b000;
    shift_op = 2'b00;
    loady = 0;
    loads = 0;
    rf_wen = 0;
    rf_waddr = 3'b000;
    rf_raddra = 3'b000;
    rf_raddrb = 3'b000;
    sximm8 = 16'h0000;
    sximm5 = 16'h0000;
    // Apply reset
    #10;
    rst = 0;
  end
endtask

task automatic check_register(input [2:0] regnum, input [15:0] expected_value);
  begin
    if (DUT.RF_inst.registers[regnum] !== expected_value) begin
      $display("Error: Error: Register R%0d has value 0x%04h, expected 0x%04h", regnum, DUT.RF_inst.registers[regnum], expected_value);
      err = 1;
    end else begin
      $display("Info: Register R%0d has correct value: 0x%04h", regnum, DUT.RF_inst.registers[regnum]);
    end
  end
endtask 

task automatic movi(input [2:0] regnum, input [15:0] value);
  // Move in immediate value to register using datapath
   begin
    @(negedge clk);
    vsel = 1;               // Select immediate value for sximm8
    asel = 0;               // Not used in this operation
    bsel = 0;               // Not used in this operation
    ALUop = ADD;            // Not used in this operation, but set to ADD for clarity
    shift_op = NOSHIFT;     // Not used in this operation
    loady = 0;              // Not used in this operation
    loads = 0;              // Not used in this operation
    rf_wen = 1;             // Enable write
    rf_waddr = regnum;      // Write to destination register
    rf_raddra = 3'b000;     // Not used in this operation
    rf_raddrb = 3'b000;     // Not used in this operation
    sximm8 = value;         // Set immediate value
    sximm5 = 16'h0000;      // Not used in this operation
    @(negedge clk);
    rf_wen = 0; // Disable write after one cycle
  end
endtask

task automatic arithmatic_op(
  input [2:0] oprand,
  input [2:0] dest_reg, 
  input [2:0] src_regA,
  input [1:0] shift_type,
  input [2:0] src_regB
  );
  begin
    @(negedge clk);
    // Stage 1: Load data and perform ALU execution
    vsel = 0;               
    asel = 0;               
    bsel = 0;               
    ALUop = oprand;
    shift_op = shift_type;
    loady = 1;
    loads = 1;
    rf_wen = 0;  
    rf_waddr = dest_reg; 
    rf_raddra = src_regA; 
    rf_raddrb = src_regB;   
    sximm8 = 16'h0000;        // Not used in this operation
    sximm5 = 16'h0000;      // Not used in this operation

    @(negedge clk);
    // Stage 2: Write back result to register file
    loady = 0; // Disable load Y
    loads = 0; // Disable load S
    rf_wen = 1; // Enable write
    @(negedge clk);
    rf_wen = 0; // Disable write after one cycle
    ALUop = 3'b000; // Reset ALUop
    shift_op = 2'b00; // Reset shift_op
    rf_raddra = 3'b000; // Reset read addresses
    rf_raddrb = 3'b000;
    rf_waddr = 3'b000; // Reset write address
  end
endtask

task automatic arithmatic_op_imm(
  input [2:0] oprand,
  input [2:0] dest_reg, 
  input [2:0] src_regA,
  input [15:0] immediate_value
  );
  //shift_op = 00, bsel = 1
  begin
    @(negedge clk);
    // Stage 1: Load data and immediate value, perform ALU execution
    vsel = 0;               
    asel = 0;               
    bsel = 1;     
    ALUop = oprand;
    shift_op = NOSHIFT;
    loady = 1;
    loads = 1;
    rf_wen = 0;  
    rf_waddr = dest_reg; 
    rf_raddra = src_regA; 
    rf_raddrb = 3'b000;
    sximm8 = 16'h0000;
    sximm5 = immediate_value; 
    @(negedge clk);
    // Stage 2: Write back result to register file
    loady = 0; // Disable load Y
    loads = 0; // Disable load S
    rf_wen = 1; // Enable write
    @(negedge clk);
    rf_wen = 0; // Disable write after one cycle
    ALUop = 3'b000; // Reset ALUop
    shift_op = 2'b00; // Reset shift_op
    rf_raddra = 3'b000; // Reset read addresses
    rf_raddrb = 3'b000;
    rf_waddr = 3'b000; // Reset write address
  end
endtask

endmodule
